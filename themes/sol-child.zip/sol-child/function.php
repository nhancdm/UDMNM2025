<?php
/**
 * Storefront Child Theme functions and definitions.
 */

add_action( 'wp_enqueue_scripts', 'storefront_child_enqueue_styles' );
function storefront_child_enqueue_styles() {
    $parent_style_handle = 'storefront-style'; // Handle của stylesheet gốc Storefront

    // Enqueue stylesheet của parent theme (Storefront)
    wp_enqueue_style( $parent_style_handle, get_template_directory_uri(). '/style.css' );

    // Enqueue stylesheet của child theme, phụ thuộc vào stylesheet của parent theme
    // Điều này đảm bảo style.css của child theme được tải sau style.css của parent theme
    wp_enqueue_style( 'storefront-child-style',
        get_stylesheet_directory_uri(). '/style.css',
        array( $parent_style_handle ),
        wp_get_theme()->get('Version') // Lấy version từ file style.css của child theme
    );
}

// Thêm các hàm tùy chỉnh và enqueue Bootstrap sẽ ở dưới đây
?>